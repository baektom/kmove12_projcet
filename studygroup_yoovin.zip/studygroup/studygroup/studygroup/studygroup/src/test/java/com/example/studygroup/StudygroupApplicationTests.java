package com.example.studygroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudygroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
